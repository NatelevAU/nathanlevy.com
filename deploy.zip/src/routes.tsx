import React from 'react';
import { Switch } from 'react-router';

export default <Switch></Switch>;
