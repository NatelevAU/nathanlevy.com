import { Box, Button } from '@material-ui/core';
import React from 'react';
import ReactGA from 'react-ga';
import Helmet from 'react-helmet';
import { Link } from 'react-router-dom';

import PlaySoundButton from '../../PlaySoundButton';

import './Spin.css';
import background from '../../images/backgrounds/Home.jpg';
import Nathan from '../../images/logos/Nathan.jpg';
import NathanRogut from '../../images/logos/NathanRogut.jpeg';

const sectionStyle = {
  backgroundImage: `url(${background})`,
  backgroundPosition: 'center',
  backgroundSize: 'cover',
  backgroundRepeat: 'no-repeat',
};

const Spin: React.FC<{}> = () => {
  const GithubLink: React.FC<{}> = props => (
    <Link to={{ pathname: 'https://github.com/NatelevAU/natelev' }} target="_blank" {...props} />
  );
  const [Upgrade, setUpgrade] = React.useState(false);

  ReactGA.pageview(window.location.pathname);

  return (
    <div className="Spin" style={sectionStyle}>
      <Helmet>
        <meta name="robots" content="noindex, nofollow" />
      </Helmet>
      <header className="Spin-header">
        <img
          src={Upgrade ? NathanRogut : Nathan}
          className="Spin-logo"
          alt="Nathan Levy Headshot 2020"
        />
        <h1> Nathan {Upgrade ? 'Rogut' : 'Levy'} </h1>
        <PlaySoundButton isUpgraded={Upgrade} />
        <Box m={2}>
          <Button size="large" variant="contained" color="primary" component={GithubLink}>
            Source Code
          </Button>
        </Box>
        <Button size="large" variant="contained" color="secondary" onClick={() => setUpgrade(true)}>
          UPGRADE
        </Button>
      </header>
    </div>
  );
};

export default Spin;
